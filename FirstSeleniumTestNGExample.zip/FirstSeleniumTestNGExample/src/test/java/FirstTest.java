import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class FirstTest {

    //Declare a Webdriver variable
    public WebDriver driver;





    @BeforeClass
    public void BeforeClass (){
        //Create a new ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize(); //maximize Chrome window
        driver.get("http://www.walla.co.il"); //browse to walla website

    }




    @Test
    //print walla website URL
    public void Test01() {
        System.out.println(driver.getCurrentUrl());
       // driver.navigate().refresh(); //Refresh website

    }


    @Test
    //print walla website Title
    public void Test02() {
        System.out.println(driver.getTitle());

    }


    @Test
    //check website name is equal to the String variable using assertion
    public void Test03(){
        String actualTitleName = "וואלה!";
        String webPageName = driver.getTitle();
        Assert.assertEquals(webPageName,actualTitleName);
    }




    @AfterClass
    public void AfterClass (){
        //Close browser and end the session
        driver.quit();
    }
}

