package java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class Actions {

    WebDriver driver;

    @BeforeTest
    @Parameters("browser")
    public void setup(String browser) throws Exception {
        //Check if parameter passed from TestNG is 'firefox'
        if (browser.equalsIgnoreCase("firefox")) {
            //create firefox instance
            System.setProperty("webdriver.gecko.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\geckodriver.exe");
            driver = new FirefoxDriver();
        }
        //Check if parameter passed as 'chrome'
        else if (browser.equalsIgnoreCase("chrome")) {
            //set path to chromedriver.exe
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
            //create chrome instance
            driver = new ChromeDriver();
        }
        //Check if parameter passed as 'ie'
        else if (browser.equalsIgnoreCase("ie")) {
            //set path toIEDriverServer.exe
            System.setProperty("webdriver.ie.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\IEDriverServer.exe");
            //create InternetExplorer instance
            driver = new InternetExplorerDriver();
        } else {
            //If no browser passed throw exception
            throw new Exception("Browser is not correct");
        }


        //manage timeout
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        //maximize browser window
        driver.manage().window().maximize();


        //browse to walla website
        driver.get("https://dgotlieb.github.io/Actions/");


    }


    @Test
    public void test01_dragAndDrop() {
        WebElement locationElement = driver.findElement(By.id("drag1"));
        WebElement destinationElement = driver.findElement(By.id("div1"));
        JSUtils.JavascriptDragAndDrop(driver, locationElement, destinationElement);

    }


    @Test
    public void test02_doubleClick() {
        WebElement doubleClickElement =
                driver.findElement(By.xpath("//p[@ondblclick='doubleClickFunction()']"));
        Actions doubleClickAction = new Actions(driver);
        doubleClickAction.doubleClick(doubleClickElement);
        doubleClickAction.build().perform();

        String result = driver.findElement(By.id("demo")).getText();
        assertEquals("You double clicked", result);

    }


    @Test
    public void test03_mosueHover() {
        Actions hoverAction = new Actions(driver);
        WebElement firstHoverElement = driver.findElement(By.id("demo"));
        WebElement secondHoverElement = driver.findElement(By.id("close"));
        hoverAction.moveToElement(firstHoverElement).moveToElement(secondHoverElement).click().build().perform();
    }


    @Test
    public void test04_selectMultiple() {
        List<WebElement> elementsList = driver.findElements(By.name("kind"));
        Actions builder = new Actions(driver);
        builder.clickAndHold((WebElement) elementsList.get(0)).clickAndHold((WebElement) elementsList.get(2)).click();
        builder.build().perform();


    }

    public void test05_uploadFile() {
        driver.findElement(By.name("pic")).sendKeys("C:\\Java_workspace\\Lesson8Homework\\vcredist.bmp");
    }


    @Test
    public void test06_scrollToElement() {
        WebElement element = driver.findElement(By.id("clickMe"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void test07_scrollToLocation() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("javascript:window.scrollBy(250,350)");
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @AfterClass
    public void AfterClass()
    {
        //Close browser and end the session
        driver.quit();
    }
}
