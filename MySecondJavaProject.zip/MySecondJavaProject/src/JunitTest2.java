import com.sun.java.util.jar.pack.DriverResource;
import org.junit.*;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class JunitTest2 {

    @Rule
    public Timeout x = Timeout.seconds(2);

    private static  WebDriver driver;
    @BeforeClass
    public static void bc() {
        System.out.println("bc");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("-incognito");
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("http://www.google.com");

    }



    @Test
    //public void getURL() {
    public void Test01() {
        System.out.println(driver.getCurrentUrl());

    }


    @Test
    //public void getTitle() {
    public void Test02() {
        System.out.println(driver.getTitle());

    }

    @Test
    //public void getPageSource() {
    public void Test03() {
        //string.handle = driver.getWindowHandle();
        System.out.println(driver.getWindowHandle());
        driver.navigate().back();
        driver.navigate().to("http://www.google.com");
    }

    @Test
    //public void getPageSource() {
    public void Test04() {
        System.out.println(driver.getPageSource());

    }





    @AfterClass
    public static void ac() {
        System.out.println("ac");
        // driver.close();  //close current tab
         driver.quit();  //close all tabs and session/process
    }
}


