/* check ynet website in Firefox
   using selenium Web driver  */

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;



import javax.xml.ws.spi.WebServiceFeatureAnnotation;

import static org.junit.Assert.*;


public class HomeworkTest2 {
        private static WebDriver driver;
        private String webPageName = "ynet";
        private WebServiceFeatureAnnotation By;


        @BeforeClass
        public static void BeforeClass() {
            System.setProperty("webdriver.gecko.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\geckodriver.exe");
            FirefoxOptions options = new FirefoxOptions();
            driver = new FirefoxDriver(options);
            driver.manage().window().maximize();
            driver.get("http://www.ynet.co.il");
        }

        @Test
        //print ynet website URL
        public void Test01() {
            System.out.println(driver.getCurrentUrl());
            driver.navigate().refresh(); //Refresh website

        }

        @Test
        //print ynet website Title
        public void Test02() {
            System.out.println(driver.getTitle());

        }


        @Test
        //check website name is equal to the String variable using assertion
        public void Test03(){
            String actualTitleName = "ynet";
            Assert.assertEquals(webPageName,actualTitleName);
        }





        @AfterClass
        public static void afterClassEnds(){
            driver.quit();
        }
    }

