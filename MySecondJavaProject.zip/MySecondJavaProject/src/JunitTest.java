import org.junit.*;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JunitTest {

    @Rule
    public Timeout x = Timeout.seconds(2);

    @BeforeClass
    public static void bc() {
        System.out.println("bc");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("http://www.google.com");
        driver.close();  //close tab
        driver.quit();  //close all tabs

    }



    @Test
    public void test01() {
        System.out.println("test01");
    }

    @Test
    public void test02() {
        int x = 4;
        int y = 5;
        Assert.assertEquals(x,y);
        System.out.println("test02");
//        if (x==y){
//            System.out.println(1);
//            System.out.println(1);
//            System.out.println(1);
//        }else{
//            System.out.println(2);
//            System.out.println(2);
//            System.out.println(2);
//        }
    }

    @Test
    public void test03() {
        int x = 7;
        int y = 7;
        Assert.assertEquals(x,y);

    }

    @Test(timeout = 1)
    public void test04() {
     //   for (int i = 0; i < 100000000; i++) {
            System.out.println("test02");
      //  }
    }

    @AfterClass
    public static void ac() {
        System.out.println("ac");
    }
}
