import java.util.ArrayList;

public class Data {
    public static void main(String[] args) {

//        int[] numbers = new int[3];
//        numbers[0]= 3;
//        System.out.println(numbers [0]);
//
//
//        int[] numbers2 = {2, 3, 8};
//
//        for (int i =0;i<numbers2.length;i++) {
//            System.out.println(numbers2[i]);
//
//        ArrayList<Double> words= new ArrayList<>();
//        words.add(1.2);
//            System.out.println(words.get(0));
//
//
//
//
//
//         for (int i2 = 0; i2 < words.size(); i2++) {
//             System.out.println(words.get(i2));
//         }


         String a = "hello";
         String b = "HELLO";

         if (a.equals(b)) {
             System.out.println("hello");
         }


        }
    }

