/* check walla website in Chrome
   using selenium Web driver  */

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import javax.xml.ws.spi.WebServiceFeatureAnnotation;

import static org.junit.Assert.*;


public class HomeworkTest1 {
    private static WebDriver driver;
    private String webPageName = "walla";
    private WebServiceFeatureAnnotation By;


    @BeforeClass
    public static void BeforeClass() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);
        driver.manage().window().maximize(); //maximize Chrome window
        driver.get("http://www.walla.co.il"); //browse to walla website
    }

    @Test
    //print walla website URL
    public void Test01() {
        System.out.println(driver.getCurrentUrl());
            driver.navigate().refresh(); //Refresh website

    }

    @Test
    //print walla website Title
    public void Test02() {
        System.out.println(driver.getTitle());

    }


    @Test
    //check website name is equal to the String variable using assertion
    public void Test03(){
        String actualTitleName = "walla";
        Assert.assertEquals(webPageName,actualTitleName);
    }





    @AfterClass
    public static void afterClassEnds(){
        driver.quit();
    }
}