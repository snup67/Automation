package parallelTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import static org.testng.AssertJUnit.assertEquals;

public class GoogleTranslateTestMultipleBrowser {
    WebDriver driver;


    /**
     * This function will execute before each Test tag in testng.xml
     *
     * @param browser
     * @throws Exception
     */

    @BeforeTest
    @Parameters("browser")
    public void setup(String browser) throws Exception {
        //Check if parameter passed from TestNG is 'firefox'
        if (browser.equalsIgnoreCase("firefox")) {
            //create firefox instance
            System.setProperty("webdriver.gecko.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\geckodriver.exe");
            driver = new FirefoxDriver();
        }
        //Check if parameter passed as 'chrome'
        else if (browser.equalsIgnoreCase("chrome")) {
            //set path to chromedriver.exe
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\chromedriver.exe");
            //create chrome instance
            driver = new ChromeDriver();
        }
        //Check if parameter passed as 'ie'
        else if (browser.equalsIgnoreCase("ie")) {
            //set path toIEDriverServer.exe
            System.setProperty("webdriver.ie.driver", "C:\\Users\\Shalom\\Downloads\\selenium-java-3.141.59\\IEDriverServer.exe");
            //create InternetExplorer instance
            driver = new InternetExplorerDriver();
        } else {
            //If no browser passed throw exception
            throw new Exception("Browser is not correct");
        }

        //manage timeout
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        //browse to walla website
        //driver.get("http://www.walla.co.il");


    }


    @Test
    public void testA() throws InterruptedException {

        driver.get("https://translate.google.com/");

        //print translate.google website URL
        System.out.println(driver.getCurrentUrl());

        // find element by ClassName
        System.out.println("find element by ClassName");
        WebElement translateButton = driver.findElement(By.className("orig"));
        System.out.println(translateButton);

        // find element by ID
        System.out.println("find element by ID");
        WebElement SourceArea = driver.findElement(By.id("source"));
        System.out.println(SourceArea);



    }


    @Test
    public void testB() throws InterruptedException {

        driver.get("https://www.youtube.com/");

        //print  website URL
        System.out.println(driver.getCurrentUrl());

        // find element by ID
        System.out.println("find element by ID");
        WebElement youTubeButton = driver.findElement(By.id("logo-icon"));
        System.out.println(youTubeButton);


    }


    @Test
    public void testC() throws InterruptedException {

        driver.get("https://www.seleniumhq.org/");

        //print  website URL
        System.out.println(driver.getCurrentUrl());

        //find and print  search text field
        WebElement seleniumElement = driver.findElement(By.name("q"));
        System.out.println(seleniumElement);


    }


    @Test
    public void testD() throws InterruptedException {

        driver.get("https://www.amazon.com/");

        //print  website URL
        System.out.println(driver.getCurrentUrl());

        String expectedAmazonTitle = "Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more";

       assertEquals(expectedAmazonTitle,driver.getTitle());

        WebElement amazonSearchBar = driver.findElement(By.id("twotabsearchtextbox"));
        amazonSearchBar.sendKeys("Leather shoes");
        amazonSearchBar.submit();
    }


    @Test
    public void testE() throws InterruptedException {

        driver.get("https://translate.google.com/");

        //print translate.google website URL
        System.out.println(driver.getCurrentUrl());

        WebElement a = driver.findElement(By.id("source"));
        a.sendKeys("שלום");
        a.submit();

    }


    @Test
    public void testF() throws InterruptedException {

        driver.get("https://www.youtube.com/");

        //print  website URL
        System.out.println(driver.getCurrentUrl());

        driver.findElement(By.name("search_query")).sendKeys("רביד פלוטניק - נתראה בגלגול הבא / Ravid Plotnik - In The Next Lifetime");
        driver.findElement(By.id("search-icon-legacy")).submit();

    }


    @Test
    public void testG() throws InterruptedException {

        driver.get("https://dgotlieb.github.io/Controllers/");

        //print  website URL
        System.out.println(driver.getCurrentUrl());

        WebElement list = driver.findElement(By.className("table5"));
        System.out.println(list);
/*
        int i;
        for (i = 0; list.findElements(By.name("group1")); i++) {
            WebElement tempElement = list.getText("i");
            if (tempElement.getAttribute("value").equals("Cheese")) {
                tempElement.click();
            }
*/
        Select dropdownmenue = new Select(driver.findElement(By.name("dropdownmenu")));
        dropdownmenue.selectByValue("Milk"); for (int i = 0; i < dropdownmenue.getOptions().size(); i++) {
            System.out.println(dropdownmenue.getOptions().get(i).getText());
        }

        }


        @AfterClass
        public void AfterClass()
        {
            //Close browser and end the session
            driver.quit();
        }


    }


